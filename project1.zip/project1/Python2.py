def pal(num, x=None):
    x1 = num[::-1]
    if x1 ==x:
        print('palindrome')
    else:
        print('not a palindrome')
        print(pal('edureka'))





